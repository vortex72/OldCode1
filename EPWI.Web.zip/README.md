# README #

### What is this repository for? ###
* This is the new MVC 5.0 .Net 4.6 version of the EPWI web site. It requires Visual Studio 2015 or later.

### Who do I talk to? ###

* ebyrd@hattonpoint.com
* jhormachea@hattonpoint.com