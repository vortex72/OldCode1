﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
////using EPWI.Components.Exceptions;
//using System.Web.Mvc;

//namespace EPWI.Web.Utility
//{
//  public static class ExtensionMethods
//  {
//    public static void CopyToModelState(this RuleException ruleException, ModelStateDictionary modelState, string prefix)
//    {
//      foreach (string key in ruleException.Errors)
//        foreach (string value in ruleException.Errors.GetValues(key))
//          modelState.AddModelError(string.IsNullOrEmpty(prefix) ? key : prefix + "." + key, value);
//    }
//  }
//}
