using EPWI.Web.Filters;

namespace EPWI.Web.Controllers
{
    [LogRequest]
    public class LoggingController : EpwiController
    {
    }
}
