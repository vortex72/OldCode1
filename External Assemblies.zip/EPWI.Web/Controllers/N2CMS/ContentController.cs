using N2.Web;
using N2.Web.Mvc;
using EPWI.Web.Models.N2CMS;

namespace EPWI.Web.Controllers.N2CMS
{
    [Controls(typeof(AbstractPage))]
    public class ContentController : ContentController<AbstractPage>
    {

    }
}
