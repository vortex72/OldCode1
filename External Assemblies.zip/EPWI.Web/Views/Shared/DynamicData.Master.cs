﻿using System;

namespace EPWI.Web.Views.Shared
{
  public partial class DynamicData : System.Web.UI.MasterPage
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}