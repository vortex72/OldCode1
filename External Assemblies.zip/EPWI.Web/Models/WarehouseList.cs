﻿namespace EPWI.Web.Models
{
  public static class WarehouseList
  {
    public static string[] Warehouses = new string[] { "DAL", "HOU", "OAK", "OKC", "SAN", "ALB", "DEN", "PHX", "ANC", "PDX", "TAC", "LA1" };
  }
}
