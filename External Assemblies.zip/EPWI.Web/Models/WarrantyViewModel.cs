﻿using System.Collections.Generic;
using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class WarrantyViewModel
  {
    public int OrderItemID { get; set; }
    public decimal KitPrice { get; set; }
    public IEnumerable<Warranty> Warranties { get; set; }
    public ICustomerData CustomerData { get; set; }
    public int View { get; set; }
  }
}
