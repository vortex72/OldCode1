﻿using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class MenuViewModel
  {
    public ICustomerData CustomerData { get; set; }
    public bool QuotesExist { get; set; }
    public bool KitExists { get; set; }
  }
}
