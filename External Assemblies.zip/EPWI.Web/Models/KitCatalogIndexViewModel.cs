﻿using System.Collections.Generic;
using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class KitCatalogIndexViewModel
  {
    public IEnumerable<Manufacturer> Manufacturers { get; set; }
  }
}
