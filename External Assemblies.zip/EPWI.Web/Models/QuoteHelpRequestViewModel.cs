﻿using System.Collections.Generic;
using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class QuoteHelpRequestViewModel
  {
    public int QuoteID { get; set; }
    public bool QuoteSaved { get; set; }
    public IEnumerable<CustomerServiceRep> CustomerServiceReps { get; set; }
  }
}