﻿using System.Collections.Generic;

namespace EPWI.Web.Models.N2CMS
{
  public class ContainerViewModel<C,I>
  {
    public C Container { get; set; }
    public IEnumerable<I> Items { get; set; }
  }
}
