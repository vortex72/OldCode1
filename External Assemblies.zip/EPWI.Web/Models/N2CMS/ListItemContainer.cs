﻿using EPWI.Web.Models.N2CMS.EPWI.Web.Models.N2CMS;
using N2;

namespace EPWI.Web.Models.N2CMS
{
    [Definition("List Item Collection")]
    public class ListItemContainer : ItemContainer<ListItemPage>
    {

    }
}
