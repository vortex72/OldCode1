﻿using N2;

namespace EPWI.Web.Models.N2CMS
{
    [PageDefinition("Catalog Page")]
    public class CatalogPage : ListItemPage
    {

    }
}
