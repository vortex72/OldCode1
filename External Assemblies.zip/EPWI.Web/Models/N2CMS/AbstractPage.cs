﻿using N2.Details;
using N2;

namespace EPWI.Web.Models.N2CMS
{
    [WithEditableTitle, WithEditableName]
    public abstract class AbstractPage : ContentItem, INode
    {
        public virtual string PreviewUrl
        {
            get { return Url; }
        }
    }
}
