﻿using System.Linq;
using N2;
using EPWI.Components.Models;

namespace EPWI.Web.Models.N2CMS
{
  public class CatalogViewModel
  {
    public ContentItem Back { get; set; }
    public CatalogPage Item { get; set; }
    public IQueryable<Catalog> CatalogItems { get; set; }
  }
}
