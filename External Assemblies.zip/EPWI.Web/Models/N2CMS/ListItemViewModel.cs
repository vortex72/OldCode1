﻿using N2;

namespace EPWI.Web.Models.N2CMS
{
  public class ListItemViewModel
  {
    public ContentItem Back { get; set; }
    public ListItemPage Item { get; set; }
  }
}
