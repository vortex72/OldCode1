﻿using System.Linq;
using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class QuotesViewModel
  {
    public IQueryable<QuoteDetail> Quotes { get; set; }
    public ICustomerData CustomerData { get; set; }
    public bool OpenOrderExists { get; set; }
    public bool IsEmployee { get; set; }
  }
}