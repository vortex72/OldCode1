﻿namespace EPWI.Web.Models
{
  public class SessionStore
  {
    public string LastViewedKit { get; set; }
    public bool ReturnToLookup { get; set; }
  }
}