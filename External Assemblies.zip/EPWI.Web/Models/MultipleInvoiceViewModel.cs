﻿using System.Collections.Generic;
using EPWI.Components.Models;

namespace EPWI.Web.Models
{
  public class MultipleInvoiceViewModel
  {
    public ICustomerData CustomerData { get; set; }
    public IEnumerable<Invoice> Invoices { get; set; }
  }
}
