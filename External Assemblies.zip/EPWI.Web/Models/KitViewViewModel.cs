﻿namespace EPWI.Web.Models
{
  public class KitViewViewModel : KitModelBase
  {
    public long SavedConfigurationID { get; set; }

    public bool AllowKitConfiguration { get; set; }
  }
}
