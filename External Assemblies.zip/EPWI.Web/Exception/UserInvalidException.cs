﻿using System;

namespace EPWI.Web.Exception
{
  public class UserInvalidException : ApplicationException
  {
  }
}