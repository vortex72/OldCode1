﻿using System;

namespace EPWI.Components.Exceptions
{
  public class KitNoNipcCodeFoundException : ApplicationException
  {
    public KitNoNipcCodeFoundException(string message): base(message)
    {

    }

  }
}
