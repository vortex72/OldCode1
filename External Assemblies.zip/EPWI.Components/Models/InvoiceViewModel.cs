﻿namespace EPWI.Components.Models
{
  public class InvoiceViewModel
  {
    public Invoice Invoice { get; set; }
    public ICustomerData CustomerData { get; set; }
  }
}
