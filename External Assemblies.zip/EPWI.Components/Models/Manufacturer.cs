﻿namespace EPWI.Components.Models
{
  public class Manufacturer
  {
    public string Name { get; set; }
    public string Make { get; set; }
  }
}
