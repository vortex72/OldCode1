﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EPWI.Components.Models
{
  [ScaffoldTable(true)]
  [DisplayName("Interchange Exceptions")]
  public partial class InterchangeException
  {
  }
}
