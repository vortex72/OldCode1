﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace EPWI.Components.Models
{
  [ScaffoldTable(true)]
  [DisplayName("Locations")]
  public partial class Location
  {
  }
}
