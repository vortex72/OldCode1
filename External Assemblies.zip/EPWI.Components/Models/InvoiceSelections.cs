﻿namespace EPWI.Components.Models
{
  public class InvoiceSelections
  {
    public string InvoiceNumber { get; set; }
    public bool Selected { get; set; }
  }
}
