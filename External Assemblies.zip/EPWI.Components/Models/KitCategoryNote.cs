﻿namespace EPWI.Components.Models
{
  public class KitCategoryNote
  {
    public int NoteOrdinal { get; set; } // used to track notes that we have displayed
    public int CategoryCode { get; set; }
    public string Note { get; set; }

  }
}
