namespace EPWI.Components.Models
{
    partial class Slideshow
    {
    }

    partial class EPWIDataContext
    {
    }
}