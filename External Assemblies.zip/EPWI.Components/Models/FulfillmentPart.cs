﻿namespace EPWI.Components.Models
{
  public class FulfillmentPart
  {
    public string OriginalPartNipc { get; set; }
    public int OriginalSequenceNumber { get; set; }
    public int OriginalQuantity { get; set; }
    public string InterchangePartNipc { get; set; }
    public int InterchangeQuantity { get; set; }
    public string InterchangeWarehouse { get; set; }
    public decimal InterchangePrice { get; set; }
    public string InterchangeType { get; set; }
    public int InterchangeCategory { get; set; }
  }
}
