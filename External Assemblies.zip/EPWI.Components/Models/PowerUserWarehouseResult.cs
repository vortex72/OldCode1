﻿namespace EPWI.Components.Models
{
  public class PowerUserWarehouseResult
  {
    public string AssignedWarehouse { get; set; }
    public string PrimaryWarehouse { get; set; }
    public string SecondaryWarehouse { get; set; }
  }
}