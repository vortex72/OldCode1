﻿namespace EPWI.Components.Models
{
  public class Warranty
  {
    public int Nipc { get; set; }
    public int OrderItemID { get; set; }
    public decimal Price { get; set; }
    public string Description { get; set; }
  }
}
