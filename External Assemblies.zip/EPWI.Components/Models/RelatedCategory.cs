﻿namespace EPWI.Components.Models
{
    public enum RelatedCategory
    {
        Undefined,
        CrankKit,
        IntakeValves,
        ExhaustValves,
        ValveSprings,
        ValveGuides,
        PushRods,
        RockerArms,
        OilPumpScreens,
        ConnectingRods,
        CylinderSleeves,
        BalancerSleeve,
        SpringShims
    }
}
