﻿namespace EPWI.Components.Models
{
  public enum ShippingCarrierType
  {
    Undefined,
    UPS,
    FedEx
  }
}
