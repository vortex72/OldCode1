﻿namespace EPWI.Components.Models
{
  public class EpwiAcesSubCategory
  {
    public int ID { get; set; } 
    public string Name { get; set; }
  }
}