﻿namespace EPWI.Components.Models
{
  public enum InvoiceSearchDirection
  {
    Before, 
    After
  }
}
