﻿using System.ComponentModel.DataAnnotations;

namespace EPWI.Components.Models
{
  [MetadataType(typeof(SlideshowMetadata))]
  public partial class Slideshow
  {
  }
}
