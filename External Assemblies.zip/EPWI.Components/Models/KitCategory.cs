﻿namespace EPWI.Components.Models
{
	public enum KitCategory
	{
    Ktrack,
    AdditionalParts,
		Rings,
		RodBearings,
		GasketSet,
		Pistons,
		MainBearings,
		CamBearings,
		OilPump,
		FreezePlugs,
		PinBushings,
		Camshaft,
		Lifters,
		TimingKit
	}
}
