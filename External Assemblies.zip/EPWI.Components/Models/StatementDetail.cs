﻿using System;

namespace EPWI.Components.Models
{
  public class StatementDetail
  {
    public DateTime TransactionDate { get; set; }
    public string TransactionType { get; set; }
    public string TransactionTypeDescription { get; set; }
    public string ReferenceNumber { get; set; }
    public string TermsCode { get; set; }
    public decimal TransactionAmount { get; set; }
    public string Note { get; set; }



  }
}
