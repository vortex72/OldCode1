﻿using System.ComponentModel.DataAnnotations;

namespace EPWI.Web.Models
{
  public class ResetPasswordModel
  {
    [Required(ErrorMessage="Username is required.")]
    public string Username { get; set; }
  }
}
