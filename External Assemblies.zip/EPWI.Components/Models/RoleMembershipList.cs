﻿namespace EPWI.Components.Models
{
  public class RoleMembershipItem
  {
    public int RoleID { get; set; }
    public string RoleKey { get; set; }
    public string RoleDescription { get; set; }
    public bool IsInRole { get; set; }
  }
}
