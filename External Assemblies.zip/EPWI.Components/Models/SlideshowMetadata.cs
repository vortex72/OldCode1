﻿using System.ComponentModel.DataAnnotations;

namespace EPWI.Components.Models
{
  public class SlideshowMetadata
  {
    [Required]
    public string Link { get; set; }
  }
}
