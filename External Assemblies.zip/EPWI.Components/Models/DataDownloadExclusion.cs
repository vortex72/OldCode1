﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace EPWI.Components.Models
{
  [ScaffoldTable(true)]
  [DisplayName("Data Download Exclusions")]
  public partial class  DataDownloadExclusion
  {
  }
}
