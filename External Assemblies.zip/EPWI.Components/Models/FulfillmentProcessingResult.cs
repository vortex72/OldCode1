﻿using System.Collections.Generic;
using System.Data;

namespace EPWI.Components.Models
{
  public class FulfillmentProcessingResult
  {
    public string ResultCode { get; set; }
    public IEnumerable<string> ProcessedNipcCodes { get; set; }
    public IEnumerable<string> ProcessedWarehouses { get; set; }
    public DataTable FulfillmentProcessingRecords { get; set; }
  }
}
